package _211047011;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;  



@SuppressWarnings("serial")
public class StudentUpdate  extends HttpServlet 
{   
	String dbURL1 = "jdbc:sqlserver://DESKTOP-HT8RAPF:1433;databaseName=Labsessionals;encrypt=true;trustServerCertificate=true;";
	String user = "charan";
	String pass = "1234";
	Connection conn = null;

	public void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	   	
		 try {
    		 
	         	
	         	conn = DriverManager.getConnection(dbURL1, user, pass);
	         } 
		 
	         catch (SQLException  ex)
	         {
	             ex.printStackTrace();
	         }
		 try {

		 if (conn != null) {
			 
			 	String rnum1= request.getParameter("roll_no");
				int roll_no = Integer.parseInt(rnum1);
				
				String name= request.getParameter("name");
				String branch= request.getParameter("branch");
				String Address= request.getParameter("Address");
				
				
				
				PreparedStatement ps=conn.prepareStatement("update student set name = ?, branch = ?, Address = ? where roll_no = ?;");
				
				ps.setString(1,name);
				ps.setString(2,branch);
				ps.setString(3,Address);
				ps.setInt(4,roll_no);
				ps.executeUpdate();
				
				PrintWriter out = response.getWriter();
				
				
				response.setContentType("text/html");
				out.println("<script type=\"text/javascript\">");  
	            out.println("alert('Student updated sucessfully');");  
	            out.println("</script>");
				
				conn.close();
   		 
   		 
		 }
		
   		 
   	 }
		 catch (SQLException e) 
	        {
	            e.printStackTrace();
	        }
		 catch (NumberFormatException  e) 
	        {
			 PrintWriter out = response.getWriter();
				response.setContentType("text/html");
	            e.printStackTrace();
	            out.println("<script type=\"text/javascript\">");  
	            out.println("alert('Please enter the valid roll number');");  
	            out.println("</script>");
	        }
	}
}
	

	      
	
