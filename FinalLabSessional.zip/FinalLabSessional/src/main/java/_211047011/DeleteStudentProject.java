package _211047011;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse; 
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@SuppressWarnings("serial")
public class DeleteStudentProject extends HttpServlet 
		{   
			String dbURL1 = "jdbc:sqlserver://DESKTOP-HT8RAPF:1433;databaseName=Labsessionals;encrypt=true;trustServerCertificate=true;";
			String user = "charan";
			String pass = "1234";
			Connection conn = null;

			public void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			   	
				 try {
		    		 
			         	
			         	conn = DriverManager.getConnection(dbURL1, user, pass);
			         } 
				 
			         catch (SQLException  ex)
			         {
			             ex.printStackTrace();
			         }
				 try {

				 if (conn != null) {
					 
					 	String rnum1= request.getParameter("roll_no");
						int rollno = Integer.parseInt(rnum1);
										
						PreparedStatement ps=conn.prepareStatement("delete from student_project where rollno = ?");
						ps.setInt(1,rollno); 
						PrintWriter out = response.getWriter();
						response.setContentType("text/html");
						if (ps.executeUpdate() > 0) {
						
						
							response.setContentType("text/html");
							out.println("<script type=\"text/javascript\">");  
				            out.println("alert('Student deleted sucessfully');");  
				            out.println("</script>");
						
						conn.close();
						}
						else
						{
							response.setContentType("text/html");
							out.println("<script type=\"text/javascript\">");  
				            out.println("alert('Student not found');");  
				            out.println("</script>");
						}
		   		 
		   		 
				 }
				
		   		 
		   	 }
				 catch (SQLException e) 
			        {
			            e.printStackTrace();
			        }
				 catch (NumberFormatException  e) 
			        {
					 PrintWriter out = response.getWriter();
						response.setContentType("text/html");
			            e.printStackTrace();
			            out.println("<script type=\"text/javascript\">");  
			            out.println("alert('Please enter the roll number');");  
			            out.println("</script>");
			        }
			}
		}
			

			      
			
