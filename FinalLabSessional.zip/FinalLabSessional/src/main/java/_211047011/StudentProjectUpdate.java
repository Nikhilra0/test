package _211047011;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse; 


@SuppressWarnings("serial")
public class StudentProjectUpdate extends HttpServlet 
	{   
		String dbURL1 = "jdbc:sqlserver://DESKTOP-HT8RAPF:1433;databaseName=Labsessionals;encrypt=true;trustServerCertificate=true;";
		String user = "charan";
		String pass = "1234";
		Connection conn = null;

		public void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		   	
			 try {
	    		 
		         	
		         	conn = DriverManager.getConnection(dbURL1, user, pass);
		         } 
			 
		         catch (SQLException  ex)
		         {
		             ex.printStackTrace();
		         }
			 try {

			 if (conn != null) {
				 
				 	String rnum1= request.getParameter("rollno");
					int rollno = Integer.parseInt(rnum1);
					
					String rnum2= request.getParameter("id");
					int id = Integer.parseInt(rnum2);
					
					
					
					PreparedStatement ps=conn.prepareStatement("update student_project set id = ? where roll_no = ?;");
					ps.setInt(2,rollno);
					ps.setInt(1,id);
					
					
					 
					ps.executeUpdate();
					
					
					PrintWriter out = response.getWriter();
					response.setContentType("text/html");
					out.println("<script type=\"text/javascript\">");  
		            out.println("alert('Student Project updated sucessfully');");  
		            out.println("</script>");
					
					conn.close();
	   		 
	   		 
			 }
			
	   		 
	   	 }
			 catch (SQLException e) 
		        {
		            e.printStackTrace();
		        }
			 catch (NumberFormatException  e) 
		        {
				 PrintWriter out = response.getWriter();
					response.setContentType("text/html");
		            e.printStackTrace();
		            out.println("<script type=\"text/javascript\">");  
		            out.println("alert('Please enter valid roll number or id');");  
		            out.println("</script>");
		        }
		}
	}
		

		      
		
